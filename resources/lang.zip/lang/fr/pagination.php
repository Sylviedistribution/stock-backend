<?php

declare(strict_types=1);

return [
    'next'     => 'Suivant &raquo;',
    'previous' => '&laquo; Précédent',
];
